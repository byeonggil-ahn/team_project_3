package com.example.perfume01.service;

import com.example.perfume01.dto.QaDTO;

import java.util.List;

public interface QaService {

    List<QaDTO> selectList();

}
