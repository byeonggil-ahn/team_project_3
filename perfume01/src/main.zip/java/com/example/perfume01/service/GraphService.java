package com.example.perfume01.service;

import com.example.perfume01.dto.GraphDTO;

import java.util.List;

public interface GraphService {
    List<GraphDTO> productGraph(GraphDTO dto);

}
