package com.example.perfume01.dto;

import lombok.Data;

@Data
public class BoardDTO {

    private int qa_no;
    private String member_id;
    private String qa_title;
    private String qa_content;
    private String qa_answer;
    private String qa_head;
    private String qa_secret;
    private String qa_regdate;

}
