package com.example.perfume01.dto;

import lombok.Data;

@Data
public class ResponseDTO {
    int err_code;
    String msg;

}
