package com.example.perfume01.dao;

import com.example.perfume01.dto.CartProductInfoDTO;
import mapperInterface.CartMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CartProductInfoDAOImpl implements CartProductInfoDAO {

//    @Autowired
//    CartMapper mapper;
//
//    @Override
//    public List<CartProductInfoDTO> cartInfoList(String member_id) {
//        return mapper.cartInfoList(member_id);
//    }
}
