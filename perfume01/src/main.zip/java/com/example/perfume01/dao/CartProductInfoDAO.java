package com.example.perfume01.dao;

import com.example.perfume01.dto.CartProductInfoDTO;

import java.util.List;

public interface CartProductInfoDAO {

//    List<CartProductInfoDTO> cartInfoList(String member_id);

}
