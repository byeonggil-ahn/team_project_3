package com.example.perfume01.dao;

import com.example.perfume01.dto.QaDTO;

import java.util.List;

public interface QaDAO {

    List<QaDTO> selectList();

}
