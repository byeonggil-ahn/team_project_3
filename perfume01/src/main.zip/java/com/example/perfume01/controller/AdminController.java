package com.example.perfume01.controller;

public class AdminController {
}
