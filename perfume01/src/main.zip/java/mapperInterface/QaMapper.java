package mapperInterface;

import com.example.perfume01.dto.QaDTO;

import java.util.List;

public interface QaMapper {

    List<QaDTO> selectList();

}
