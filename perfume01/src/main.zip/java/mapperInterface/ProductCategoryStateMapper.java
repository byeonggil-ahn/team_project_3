package mapperInterface;

import com.example.perfume01.dto.ProductCategoryStateDTO;

import java.util.List;

public interface ProductCategoryStateMapper {

    List<ProductCategoryStateDTO> list();

}
