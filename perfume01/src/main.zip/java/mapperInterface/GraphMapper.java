package mapperInterface;

import com.example.perfume01.dto.GraphDTO;

import java.util.List;

public interface GraphMapper {

    List<GraphDTO> productGraph(GraphDTO dto);

}
