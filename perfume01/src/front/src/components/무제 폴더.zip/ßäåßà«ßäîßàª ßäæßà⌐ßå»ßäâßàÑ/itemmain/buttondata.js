
let buttondata = [
    {
        name: "ALL",
        count: 9,
        data_category : 1,
    },
    {
        name: "menu1",
        count: 3,
        data_category : 2,
    },
    {
        name: "menu2",
        count: 3,
        data_category : 3,
    },
    {
        name: "menu3",
        count: 3,
        data_category : 4,
    },
]

export default buttondata;